# 課題 15: city_country() 関数（都市と国を英語表記に）
def city_country(city, country):
    return f"{city}, {country}"


# 3つの都市と国のペアで呼び出し（英語表記）
print(city_country("Kobe", "Japan"))
print(city_country("Paris", "France"))
print(city_country("New York", "USA"))
