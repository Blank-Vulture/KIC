# 課題 10: display_message() 関数
def display_message():
    print("今日はPythonの関数の作り方と使い方を学びました！")


# 関数を呼び出してメッセージを表示する
display_message()
