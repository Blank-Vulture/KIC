# 課題 11: favorite_book() 関数
def favorite_book(title):
    print(f"私の好きな本のひとつは、『{title}』です。")


# 関数を呼び出して本のタイトルを指定する
favorite_book("嫌われる勇気")
