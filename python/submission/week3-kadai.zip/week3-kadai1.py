# 課題1

character_info = {
    'name': 'デイビッド・マルティネス',
    'age': 17,
    'city': 'ナイトシティ'
}

# 辞書に格納されている各情報を表示
print(f"氏名: {character_info['name']}")
print(f"年齢: {character_info['age']}")
print(f"住んでいる町: {character_info['city']}")
