# 課題2
favorite_numbers = {
    "ルーシー": 7,
    "メイン": 13,
    "レベッカ": 9,
    "ファラデー": 5,
    "ドリオ": 3,
}

# 各キャラクターの名前と好きな数字を表示
for name, number in favorite_numbers.items():
    print(f"{name}の好きな数字は {number} です。")
