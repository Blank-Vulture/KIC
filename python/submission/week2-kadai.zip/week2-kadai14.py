# 好きな果物をリストに入れる
favorite_fruits = ["バナナ", "りんご", "ぶどう"]

# 5つのif文で果物がリストに含まれているかをチェック
if "バナナ" in favorite_fruits:
    print("あなたは本当にバナナが好きなのですね！")

if "りんご" in favorite_fruits:
    print("あなたは本当にりんごが好きなのですね！")

if "ぶどう" in favorite_fruits:
    print("あなたは本当にぶどうが好きなのですね！")

if "オレンジ" in favorite_fruits:
    print("あなたは本当にオレンジが好きなのですね！")

if "パイナップル" in favorite_fruits:
    print("あなたは本当にパイナップルが好きなのですね！")
