odd_numbers = list(range(1, 21, 2))
for number in odd_numbers:
    print(number)