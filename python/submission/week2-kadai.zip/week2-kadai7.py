cubes = [i**3 for i in range(1, 11)]
print(cubes)
