numbers = list(range(1, 1000000))
print("Min:", min(numbers))
print("Max:", max(numbers))
print("Sum:", sum(numbers))
