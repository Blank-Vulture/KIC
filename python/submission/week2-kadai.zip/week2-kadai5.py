multiples_of_three = list(range(3, 31, 3))
for number in multiples_of_three:
    print(number)
