numbers = list(range(1, 1000001))
for number in numbers:
    print(number)
