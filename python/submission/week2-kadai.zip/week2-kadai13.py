# 変数ageに値をセット
age = 25

# if-elif-elseでライフステージを判定
if age < 2:
    print("赤ん坊")
elif age < 4:
    print("幼児")
elif age < 13:
    print("子供")
elif age < 20:
    print("少年")
elif age < 65:
    print("大人")
else:
    print("高齢者")