# エイリアンの色リストを作成
alien_colors = ["green", "yellow", "red"]

# エイリアンの色が'green'であるかどうかを判定
for alien_color in alien_colors:
    if alien_color == "green":
        print(f"{alien_color.title()}のエイリアン: プレーヤーは5点を獲得しました！")  # 'green'の場合にのみ表示
