def output(names):
    for name in names:
        print(f"dear {name}, I would like to invite you to a dinner party at my house. Please let me know if you can make it.")


guests = ["Maine", "Lucy", "Rebecca"]
output(guests)
print(f"invite guests total: {len(guests)}")
