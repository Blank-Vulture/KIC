# test_restaurant.py
from restaurant import Restaurant

# インスタンスの作成
my_restaurant = Restaurant("Cyber Diner", "Fusion Cuisine")

# メソッドの呼び出し
my_restaurant.describe_restaurant()
my_restaurant.open_restaurant()
